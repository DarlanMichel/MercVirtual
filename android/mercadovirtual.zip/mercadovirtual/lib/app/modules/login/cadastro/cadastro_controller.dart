import 'package:firebase_auth/firebase_auth.dart';
import 'package:mobx/mobx.dart';

part 'cadastro_controller.g.dart';

class CadastroController = _CadastroControllerBase with _$CadastroController;

abstract class _CadastroControllerBase with Store {
  @observable
  String email = '';

  @observable
  String senha = '';

  @observable
  String confirmaSenha = '';

  @action
  void setEmail(String _email) => email = _email;

  @action
  void setSenha(String _senha) => senha = _senha;

  @action
  void setConfirmaSenha(String _confirmaSenha) => confirmaSenha = _confirmaSenha;

  @action
  Future<bool> criarConta() async {
    if(senha != confirmaSenha){
      return false;
    }else {
      final FirebaseAuth _auth = FirebaseAuth.instance;
      final FirebaseUser user = (await _auth.createUserWithEmailAndPassword(
        email: email,
        password: senha,
      )).user;
      return true;
    }
  }
}
