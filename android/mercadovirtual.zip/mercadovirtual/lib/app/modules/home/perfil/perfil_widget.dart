import 'package:flutter/material.dart';

class PerfilWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Index 3: Perfil',
      ),
    );
  }
}
